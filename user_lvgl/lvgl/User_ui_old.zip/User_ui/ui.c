/*
 * ui.c —— 充电桩主页界面（LVGL v9）
 * 对应设计图「界面 1：主页 / 充电选择」，文本全部英文
 *
 * 布局（Flex Column，百分比自适应任意分辨率）：
 *   ① 顶栏        ~10%   标题 + 时间日期
 *   ② 欢迎区      ~35%   Welcome / Smart Charging Station / 标语
 *   ③ 功能区      ~55%   3 个菜单按钮横排（开始充电 / 充电记录 / 设置）
 */
#include "ui.h"
#include "lvgl.h"
#include "ui_start_charging.h"

#include "Button_scaling.h"      //充电界面
#include "user_Charge_Records.h" //充电记录界面

#include "user_msg.h"            //顶部消息层


lv_obj_t * scr;//屏幕
lv_obj_t * main_container;//最底层容器  用户主页容器

lv_obj_t *btn_xx   = NULL;
lv_obj_t *btn_xxx  = NULL;
lv_obj_t *btn_xxxx = NULL;
/* 按钮点击回调：预留页面跳转 */
static void menu_btn_event_cb(lv_event_t * e)
{
    lv_obj_t * btn = lv_event_get_target(e);
    uint8_t id = (uint8_t)(intptr_t)lv_obj_get_user_data(btn);

    switch (id) {
        case 0: /* Start Charging  → 跳转扫码/选枪页 */
        ui_start_charging_create();//选枪界面
            break;
        case 1: /* Charge Records  → 跳转充电记录页 */

        user_Charge_Records();//充电记录界面
            break;
        case 2: /* Settings        → 跳转系统设置页 */
// button_scaling(scr, btn_xxxx);


            break;
        default:
            break;
    }
}

/* =========================
 * 创建功能按钮：图标 + 标题 + 副标题（竖排）
 * ========================= */
static lv_obj_t * make_menu_btn(lv_obj_t * parent,
                                const char * icon, const char * title,
                                const char * subtitle, uint32_t color, int id)
{
    lv_obj_t * btn = lv_btn_create(parent);
    lv_obj_set_height(btn, LV_PCT(88));
    lv_obj_set_flex_grow(btn, 1);                    /* 三按钮等宽 */
    lv_obj_set_style_bg_color(btn, lv_color_hex(color), 0);
    lv_obj_set_style_radius(btn, 16, 0);
    lv_obj_set_style_border_width(btn, 0, 0);
    lv_obj_set_style_shadow_width(btn, 0, 0);
    lv_obj_set_style_pad_all(btn, 8, 0);

    /* 内部竖排居中：图标 / 标题 / 副标题 */
    lv_obj_set_layout(btn, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(btn, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(btn, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER,
                          LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(btn, 6, 0);

    lv_obj_t * ic = lv_label_create(btn);
    lv_label_set_text(ic, icon);
    lv_obj_set_style_text_color(ic, lv_color_white(), 0);
    lv_obj_set_style_text_font(ic, &lv_font_montserrat_20, 0);   /* 图标跟随该字号 */

    lv_obj_t * ti = lv_label_create(btn);
    lv_label_set_text(ti, title);
    lv_obj_set_style_text_color(ti, lv_color_white(), 0);
    lv_obj_set_style_text_font(ti, &lv_font_montserrat_20, 0);

    lv_obj_t * su = lv_label_create(btn);
    lv_label_set_text(su, subtitle);
    lv_obj_set_style_text_color(su, lv_color_hex(0xA8C4E0), 0);

    lv_obj_set_user_data(btn, (void *)(intptr_t)id);
    lv_obj_add_event_cb(btn, menu_btn_event_cb, LV_EVENT_CLICKED, NULL);
    return btn;
}

/* =========================
 * 主入口
 * ========================= */
void ui_create(void)
{
    /* 屏幕基础：深蓝科技背景 */
    scr = lv_screen_active();
    lv_obj_set_style_bg_color(scr, lv_color_hex(0x0D1B2A), 0);
    lv_obj_set_style_pad_all(scr, 0, 0);

    /* 最外层容器：Flex Column */
    main_container = lv_obj_create(scr);
    lv_obj_set_width(main_container, LV_PCT(100));
    lv_obj_set_height(main_container, LV_PCT(100));
    lv_obj_set_style_bg_color(main_container, lv_color_hex(0x0D1B2A), 0);
    lv_obj_set_style_pad_all(main_container, 0, 0);
    lv_obj_set_style_border_width(main_container, 0, 0);
    lv_obj_set_style_radius(main_container, 0, 0);
    lv_obj_set_layout(main_container, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(main_container, LV_FLEX_FLOW_COLUMN);

    /* =========================
     * ① 顶栏 —— 标题 + 时间日期
     * ========================= */
    ui_message_bar_create(lv_layer_top());//顶部消息栏 (设置布局为永远最顶层)

    /* =========================
     * ② 欢迎区 —— 居中三行文字
     * ========================= */
    lv_obj_t * welcome_area = lv_obj_create(main_container);
    lv_obj_set_width(welcome_area, LV_PCT(100));
    lv_obj_set_flex_grow(welcome_area, 5);
    lv_obj_set_style_bg_color(welcome_area, lv_color_hex(0x0D1B2A), 0);
    lv_obj_set_style_pad_all(welcome_area, 0, 0);
    lv_obj_set_style_pad_top(welcome_area, 70, 0);
    lv_obj_set_style_border_width(welcome_area, 0, 0);
    lv_obj_set_style_radius(welcome_area, 0, 0);
    lv_obj_set_layout(welcome_area, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(welcome_area, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(welcome_area, LV_FLEX_ALIGN_CENTER,
                          LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_row(welcome_area, 8, 0);

    /* 主标题 */
    lv_obj_t * w1 = lv_label_create(welcome_area);
    lv_label_set_text(w1, "Welcome");
    lv_obj_set_style_text_color(w1, lv_color_white(), 0);
    lv_obj_set_style_text_font(w1, &lv_font_montserrat_24, 0);

    /* 副标题 */
    lv_obj_t * w2 = lv_label_create(welcome_area);
    lv_label_set_text(w2, "Smart Charging Station");
    lv_obj_set_style_text_color(w2, lv_color_hex(0x4DA3FF), 0);
    lv_obj_set_style_text_font(w2, &lv_font_montserrat_20, 0);

    /* 标语 */
    lv_obj_t * w3 = lv_label_create(welcome_area);
    lv_label_set_text(w3, "Green Travel . Low-carbon Life");
    lv_obj_set_style_text_color(w3, lv_color_hex(0x8FA3B8), 0);

    /* =========================
     * ③ 功能区 —— 3 个菜单按钮横排
     * ========================= */
    lv_obj_t * menu_area = lv_obj_create(main_container);
    lv_obj_set_width(menu_area, LV_PCT(100));
    lv_obj_set_flex_grow(menu_area, 3);
    lv_obj_set_style_bg_color(menu_area, lv_color_hex(0x0D1B2A), 0);
    lv_obj_set_style_pad_all(menu_area, 16, 0);
    lv_obj_set_style_pad_top(menu_area, 8, 0);
    lv_obj_set_style_border_width(menu_area, 0, 0);
    lv_obj_set_style_radius(menu_area, 0, 0);
    lv_obj_set_layout(menu_area, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(menu_area, LV_FLEX_FLOW_ROW);
    lv_obj_set_style_pad_column(menu_area, 12, 0);

    /* 开始充电（绿）——扫码/充电卡 */
    btn_xx =  make_menu_btn(menu_area, LV_SYMBOL_PLAY, "Start Charging",
                  "Scan QR / Card", 0x1F8A5F, 0);
    /* 充电记录（蓝）——查看历史 */
    btn_xxx = make_menu_btn(menu_area, LV_SYMBOL_LIST, "Charge Records",
                  "View History", 0x1B4F8A, 1);
    /* 设置（蓝）——系统设置 */
    btn_xxxx = make_menu_btn(menu_area, LV_SYMBOL_SETTINGS, "Settings",
                  "System Settings", 0x7B8794, 2);
}
