#include "user_Charge_Records.h"
#include "Button_scaling.h"

extern lv_obj_t *scr;
extern lv_obj_t *btn_xxx;
extern lv_obj_t *main_container;

lv_obj_t *Charge_Records = NULL;//充电记录页面

void Charge_Record_back_btn_event_cb(lv_event_t * e)
{
    lv_obj_t * btn = lv_event_get_target(e);
    //删除充电记录页面
    lv_obj_delete(Charge_Records);
    Charge_Records = NULL;

}

void user_Charge_Records(void)
{
 // 创建充电页面，弹性布局，主轴向下
    Charge_Records = lv_obj_create(scr);
    lv_obj_set_pos(Charge_Records, 0, 0);
    lv_obj_set_size(Charge_Records, LV_PCT(100), LV_PCT(100));

    lv_obj_set_style_bg_color(Charge_Records, lv_color_hex(0x0D1B2A), 0);
    lv_obj_set_style_pad_all(Charge_Records, 0, 0);
    lv_obj_set_style_pad_row(Charge_Records, 0, 0);
    lv_obj_set_style_border_width(Charge_Records, 0, 0);
    lv_obj_set_style_outline_width(Charge_Records, 0, 0);
    lv_obj_set_style_shadow_width(Charge_Records, 0, 0);
    lv_obj_set_style_radius(Charge_Records, 0, 0);

    lv_obj_set_layout(Charge_Records, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(Charge_Records, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_scrollable(Charge_Records, false);

    //返回、快捷跳转区
    lv_obj_t *page_back = lv_obj_create(Charge_Records);

    lv_obj_set_width(page_back, LV_PCT(100));
    lv_obj_set_flex_grow(page_back, 2);
    lv_obj_set_style_bg_color(page_back, lv_color_hex(0x101820), 0);
    lv_obj_set_style_pad_all(page_back, 0, 0);
    lv_obj_set_style_pad_top(page_back, 40, 0);
    lv_obj_set_style_pad_hor(page_back, 5, 0);
    lv_obj_set_style_border_width(page_back, 0, 0);
    lv_obj_set_style_outline_width(page_back, 0, 0);
    lv_obj_set_style_shadow_width(page_back, 0, 0);
    lv_obj_set_style_radius(page_back, 0, 0);

    //退出按钮
    lv_obj_t *back_btn = lv_btn_create(page_back);
    lv_obj_set_size(back_btn, 110, 55);
    lv_obj_set_style_radius(back_btn, 0, 0);
    lv_obj_set_style_shadow_width(back_btn, 0, 0);
    lv_obj_set_style_bg_opa(back_btn, LV_OPA_0, 0);
    lv_obj_add_event_cb(back_btn, Charge_Record_back_btn_event_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *back_label = lv_label_create(back_btn);
    lv_label_set_text(back_label, LV_SYMBOL_LEFT "  BACK");
    lv_obj_set_style_text_font(back_label, &lv_font_montserrat_16, 0);
}
