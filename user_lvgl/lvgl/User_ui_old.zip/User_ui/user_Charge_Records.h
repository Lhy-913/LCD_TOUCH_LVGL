#ifndef USER_CHARGE_RECORDS_H
#define USER_CHARGE_RECORDS_H

#include "lvgl/lvgl.h"

void user_Charge_Records(void);

#endif
