#include "user_msg.h"

lv_obj_t *ui_message_bar_create(lv_obj_t *parent)
{
    lv_obj_t *top_bar = lv_obj_create(parent);
    lv_obj_set_style_bg_opa(top_bar, LV_OPA_0, 0);
    lv_obj_set_size(top_bar, LV_PCT(100),LV_PCT(10));
    lv_obj_set_pos(top_bar, 0, 0);

    lv_obj_set_style_bg_color(top_bar, lv_color_hex(0x0D1B2A), 0);
    lv_obj_set_style_pad_all(top_bar, 0, 0);
    lv_obj_set_style_pad_left(top_bar, 16, 0);
    lv_obj_set_style_pad_right(top_bar, 16, 0);
    lv_obj_set_style_border_width(top_bar, 0, 0);
    lv_obj_set_style_outline_width(top_bar, 0, 0);
    lv_obj_set_style_shadow_width(top_bar, 0, 0);
    lv_obj_set_style_radius(top_bar, 0, 0);

    lv_obj_set_layout(top_bar, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(top_bar, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(top_bar,
                          LV_FLEX_ALIGN_SPACE_BETWEEN,
                          LV_FLEX_ALIGN_CENTER,
                          LV_FLEX_ALIGN_CENTER);

    lv_obj_t *title_lbl = lv_label_create(top_bar);
    lv_obj_set_style_text_color(title_lbl, lv_color_hex(0x4DA3FF), 0);
    lv_obj_set_style_text_font(title_lbl, &lv_font_montserrat_16, 0);
    lv_label_set_text(title_lbl, LV_SYMBOL_CHARGE " SMART CHARGING STATION");

    lv_obj_t *time_lbl = lv_label_create(top_bar);
    lv_obj_set_style_text_color(time_lbl, lv_color_hex(0x8FA3B8), 0);
    lv_label_set_text(time_lbl, "11:25  2026-09-09 Tue");

    return top_bar;
}
