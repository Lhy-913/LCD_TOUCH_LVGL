#ifndef USER_MSG_H
#define USER_MSG_H

#include "lvgl/lvgl.h"
// Function declarations for handling user messages
lv_obj_t *ui_message_bar_create(lv_obj_t *parent);


#endif // USER_MSG_H
