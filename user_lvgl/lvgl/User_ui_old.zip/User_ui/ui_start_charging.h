#ifndef UI_START_CHARGING_H
#define UI_START_CHARGING_H

#include "lvgl/lvgl.h"

void ui_start_charging_create(void);

#endif
