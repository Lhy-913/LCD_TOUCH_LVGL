#ifndef UI_H
#define UI_H

#include "lvgl/lvgl.h"

void ui_create(void);

#endif
