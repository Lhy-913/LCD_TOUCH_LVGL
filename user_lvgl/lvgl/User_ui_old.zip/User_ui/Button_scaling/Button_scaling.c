#include "Button_scaling.h"

// X 坐标动画
static void charging_x_anim_cb(void *var, int32_t value)
{
    lv_obj_t *obj = var;
    lv_obj_set_x(obj, value);
}

// Y 坐标动画
static void charging_y_anim_cb(void *var, int32_t value)
{
    lv_obj_t *obj = var;
    lv_obj_set_y(obj, value);
}

// 宽度动画
static void charging_width_anim_cb(void *var, int32_t value)
{
    lv_obj_t *obj = var;
    lv_obj_set_width(obj, value);
}

// 高度动画
static void charging_height_anim_cb(void *var, int32_t value)
{
    lv_obj_t *obj = var;
    lv_obj_set_height(obj, value);
}

lv_obj_t *button_scaling(lv_obj_t *scr, lv_obj_t *btn)
{
    lv_area_t btn_area;
    lv_area_t scr_area;

    // 更新布局
    lv_obj_update_layout(scr);

    // 获取按钮屏幕坐标和大小
    lv_obj_get_coords(btn, &btn_area);
    int32_t screen_btn_x = btn_area.x1;
    int32_t screen_btn_y = btn_area.y1;
    int32_t start_w = btn_area.x2 - btn_area.x1 + 1;
    int32_t start_h = btn_area.y2 - btn_area.y1 + 1;

    // 获取 scr 屏幕坐标和大小
    lv_obj_get_coords(scr, &scr_area);
    int32_t scr_screen_x = scr_area.x1;
    int32_t scr_screen_y = scr_area.y1;
    int32_t scr_width = scr_area.x2 - scr_area.x1 + 1;
    int32_t scr_height = scr_area.y2 - scr_area.y1 + 1;

    // 将按钮屏幕坐标转换为 scr 内部坐标
    int32_t start_x = screen_btn_x - scr_screen_x;
    int32_t start_y = screen_btn_y - scr_screen_y;

    // 创建充电页面
    lv_obj_t *charging_page = lv_obj_create(scr);
    lv_obj_set_floating(charging_page, true);

    // 设置页面样式
    lv_obj_set_style_pad_all(charging_page, 0, 0);
    lv_obj_set_style_border_width(charging_page, 0, 0);
    lv_obj_set_style_radius(charging_page, 0, 0);
    lv_obj_set_style_bg_color(charging_page, lv_color_hex(0x101820), 0);
    lv_obj_set_scrollable(charging_page, false);

    // 设置页面初始位置和大小
    lv_obj_set_pos(charging_page, start_x, start_y);
    lv_obj_set_size(charging_page, start_w, start_h);

    // X：按钮位置 → 0
    lv_anim_t anim_x;
    lv_anim_init(&anim_x);
    lv_anim_set_var(&anim_x, charging_page);
    lv_anim_set_exec_cb(&anim_x, charging_x_anim_cb);
    lv_anim_set_duration(&anim_x, 150);
    lv_anim_set_values(&anim_x, start_x, 0);
    lv_anim_start(&anim_x);

    // Y：按钮位置 → 0
    lv_anim_t anim_y;
    lv_anim_init(&anim_y);
    lv_anim_set_var(&anim_y, charging_page);
    lv_anim_set_exec_cb(&anim_y, charging_y_anim_cb);
    lv_anim_set_duration(&anim_y, 150);
    lv_anim_set_values(&anim_y, start_y, 0);
    lv_anim_start(&anim_y);

    // 宽度：按钮宽度 → 全屏宽度
    lv_anim_t anim_width;
    lv_anim_init(&anim_width);
    lv_anim_set_var(&anim_width, charging_page);
    lv_anim_set_exec_cb(&anim_width, charging_width_anim_cb);
    lv_anim_set_duration(&anim_width, 150);
    lv_anim_set_values(&anim_width, start_w, scr_width);
    lv_anim_start(&anim_width);

    // 高度：按钮高度 → 全屏高度
    lv_anim_t anim_height;
    lv_anim_init(&anim_height);
    lv_anim_set_var(&anim_height, charging_page);
    lv_anim_set_exec_cb(&anim_height, charging_height_anim_cb);
    lv_anim_set_duration(&anim_height, 150);
    lv_anim_set_values(&anim_height, start_h, scr_height);
    lv_anim_start(&anim_height);

    return charging_page;
}
