#ifndef BUTTON_SCALING_H
#define BUTTON_SCALING_H
#include "lvgl/lvgl.h"
//功能按键页面动画：点击按钮时会扩大至全屏，形成页面切换的动画效果
//参数：父对象 目标按钮
lv_obj_t *button_scaling(lv_obj_t *scr, lv_obj_t *btn);

#endif
