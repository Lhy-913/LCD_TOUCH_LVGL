#include "ui_start_charging.h"
#include "Button_scaling.h"
#include <math.h>

extern lv_obj_t *scr;
extern lv_obj_t *btn_xx;
extern lv_obj_t *main_container;

lv_obj_t *charging_page = NULL;//充电页面

lv_obj_t *btn_start = NULL;//充电按钮
lv_obj_t *btn_stop  = NULL;//停止按钮

bool charging_state = false;//充电状态

void charging_create_back_btn_event_cb(lv_event_t * e)
{
    lv_obj_t * btn = lv_event_get_target(e);
    //删除充电页面
    lv_obj_delete(charging_page);
    charging_page = NULL;
    btn_start = NULL;
    btn_stop = NULL;
}

void start_btn_event_cb(lv_event_t * e)
{
    btn_start = lv_event_get_target(e);
    btn_stop = lv_obj_get_child(lv_obj_get_parent(btn_start), 1);
    lv_obj_t* label = lv_event_get_user_data(e);

    lv_obj_t *func_area = lv_obj_get_child(charging_page, 1);
    lv_obj_t *charging_status = lv_obj_get_child(func_area, 0);
    lv_obj_t *led = lv_obj_get_child(charging_status, 0);
    lv_obj_set_style_bg_color(led, lv_color_hex(0x00FF00), 0);

    charging_state = true;

    lv_label_set_text(label, LV_SYMBOL_CHARGE" Charging...");
    lv_obj_set_style_bg_color(btn_start, lv_color_hex(0x3B82F6), 0);
    lv_obj_set_style_text_font(label, &lv_font_montserrat_20, 0);
    lv_obj_center(label);

    lv_obj_set_clickable(btn_start, false);
    lv_obj_set_style_bg_opa(btn_start, LV_OPA_60, 0);
    lv_obj_set_style_text_opa(label, LV_OPA_60, 0);

    lv_obj_set_style_bg_color(btn_stop, lv_color_hex(0xEF4444), 0);//将停止按钮变为红色
    lv_obj_set_style_bg_opa(btn_stop, LV_OPA_80, 0);
}

void stop_btn_event_cb(lv_event_t * e)
{
    btn_stop = lv_event_get_target(e);
    btn_start = lv_obj_get_child(lv_obj_get_parent(btn_stop), 0);
    lv_obj_t *label = lv_obj_get_child(btn_start, 0);

    lv_obj_t *func_area = lv_obj_get_child(charging_page, 1);
    lv_obj_t *charging_status = lv_obj_get_child(func_area, 0);
    lv_obj_t *led = lv_obj_get_child(charging_status, 0);
    lv_obj_set_style_bg_color(led, lv_color_hex(0x475569), 0);

    charging_state = false;

    lv_label_set_text(label, LV_SYMBOL_PLAY" Start Charging");
    lv_obj_set_style_bg_color(btn_start, lv_color_hex(0x22C55E), 0);
    lv_obj_set_style_bg_opa(btn_start, LV_OPA_80, 0);
    lv_obj_set_style_text_font(label, &lv_font_montserrat_20, 0);
    lv_obj_set_style_text_opa(label, LV_OPA_COVER, 0);
    lv_obj_center(label);

    lv_obj_set_clickable(btn_start, true);

    lv_obj_set_style_bg_color(btn_stop, lv_color_hex(0x475569), 0);//将停止按钮变回灰色
}

void ui_start_charging_create(void)
{
    // 创建充电页面，弹性布局，主轴向下
    charging_page = lv_obj_create(scr);
    lv_obj_set_pos(charging_page, 0, 0);
    lv_obj_set_size(charging_page, LV_PCT(100), LV_PCT(100));

    lv_obj_set_style_bg_color(charging_page, lv_color_hex(0x0D1B2A), 0);
    lv_obj_set_style_pad_all(charging_page, 0, 0);
    lv_obj_set_style_pad_row(charging_page, 0, 0);
    lv_obj_set_style_border_width(charging_page, 0, 0);
    lv_obj_set_style_outline_width(charging_page, 0, 0);
    lv_obj_set_style_shadow_width(charging_page, 0, 0);
    lv_obj_set_style_radius(charging_page, 0, 0);

    lv_obj_set_layout(charging_page, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(charging_page, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_scrollable(charging_page, false);

    //返回、快捷跳转区
    lv_obj_t *page_back = lv_obj_create(charging_page);

    lv_obj_set_width(page_back, LV_PCT(100));
    lv_obj_set_flex_grow(page_back, 2);
    lv_obj_set_style_bg_color(page_back, lv_color_hex(0x101820), 0);
    lv_obj_set_style_pad_all(page_back, 0, 0);
    lv_obj_set_style_pad_top(page_back, 40, 0);
    lv_obj_set_style_pad_hor(page_back, 5, 0);
    lv_obj_set_style_border_width(page_back, 0, 0);
    lv_obj_set_style_outline_width(page_back, 0, 0);
    lv_obj_set_style_shadow_width(page_back, 0, 0);
    lv_obj_set_style_radius(page_back, 0, 0);

    //退出按钮
    lv_obj_t *back_btn = lv_btn_create(page_back);
    lv_obj_set_size(back_btn, 110, 55);
    lv_obj_set_style_radius(back_btn, 0, 0);
    lv_obj_set_style_shadow_width(back_btn, 0, 0);
    lv_obj_set_style_bg_opa(back_btn, LV_OPA_0, 0);
    lv_obj_add_event_cb(back_btn, charging_create_back_btn_event_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *back_label = lv_label_create(back_btn);
    lv_label_set_text(back_label, LV_SYMBOL_LEFT "  BACK");
    lv_obj_set_style_text_font(back_label, &lv_font_montserrat_16, 0);

    /* =========================
     * ② 功能区
     * ========================= */

    lv_obj_t *func_area = lv_obj_create(charging_page);

    lv_obj_set_width(func_area, LV_PCT(100));
    lv_obj_set_flex_grow(func_area, 6);

    lv_obj_set_style_bg_color(func_area, lv_color_hex(0x101820), 0);
    lv_obj_set_style_pad_all(func_area, 0, 0);
    lv_obj_set_style_pad_hor(func_area, 10, 0);
    lv_obj_set_style_border_width(func_area, 0, 0);
    lv_obj_set_style_outline_width(func_area, 0, 0);
    lv_obj_set_style_shadow_width(func_area, 0, 0);
    lv_obj_set_style_radius(func_area, 0, 0);

    lv_obj_set_layout(func_area, LV_LAYOUT_GRID);

    static lv_coord_t column_dsc[] = {LV_PCT(20),LV_PCT(20),LV_PCT(20),LV_PCT(20),LV_PCT(20),LV_GRID_TEMPLATE_LAST};
    static lv_coord_t row_dsc[] = {LV_PCT(20),LV_PCT(20),LV_PCT(20),LV_PCT(20),LV_PCT(20),LV_GRID_TEMPLATE_LAST};

    lv_obj_set_grid_dsc_array(func_area, column_dsc, row_dsc);

/* =========================
 * 左侧充电状态区
 * ========================= */

lv_obj_t *charging_status = lv_obj_create(func_area);

lv_obj_set_grid_cell(charging_status, LV_GRID_ALIGN_STRETCH, 0, 3,
                     LV_GRID_ALIGN_STRETCH, 0, 5);

lv_obj_set_style_bg_color(charging_status, lv_color_hex(0x101820), 0);
lv_obj_set_style_border_width(charging_status, 0, 0);
lv_obj_set_style_outline_width(charging_status, 0, 0);
lv_obj_set_style_shadow_width(charging_status, 0, 0);
lv_obj_set_style_radius(charging_status, 5, 0);

//点状LED，显示是否在充电
lv_obj_t *led = lv_obj_create(charging_status);
lv_obj_set_size(led, 5, 5);
lv_obj_set_style_radius(led, LV_RADIUS_CIRCLE, 0);
lv_obj_set_style_bg_color(led, lv_color_hex(0x475569), 0);
lv_obj_set_style_border_width(led, 0, 0);
lv_obj_set_style_shadow_width(led, 0, 0);

///* =========================
// * 渐变圆环参数
// * ========================= */

//#define BATTERY_RING_SIZE 220
//#define BATTERY_RING_WIDTH 18

//static lv_color_t battery_ring_buf[BATTERY_RING_SIZE * BATTERY_RING_SIZE];

///* =========================
// * 创建 Canvas
// * ========================= */

//lv_obj_t *battery_ring = lv_canvas_create(charging_status);
//lv_canvas_set_buffer(battery_ring,battery_ring_buf,BATTERY_RING_SIZE,BATTERY_RING_SIZE,LV_COLOR_FORMAT_RGB565);
//lv_obj_center(battery_ring);

///* =========================
// * Canvas 背景
// * ========================= */

//lv_canvas_fill_bg(battery_ring, lv_color_hex(0x101820), LV_OPA_COVER);

///* =========================
// * 圆环参数
// * ========================= */

//int cx = BATTERY_RING_SIZE / 2;
//int cy = BATTERY_RING_SIZE / 2;

//int outer_radius = BATTERY_RING_SIZE / 2 - 5;
//int inner_radius = outer_radius - BATTERY_RING_WIDTH;

///* =========================
// * 绘制完整 360° 渐变圆环
// * ========================= */

//for(int y = 0; y < BATTERY_RING_SIZE; y++) {

//    for(int x = 0; x < BATTERY_RING_SIZE; x++) {

//        int dx = x - cx;
//        int dy = y - cy;
//        int distance2 = dx * dx + dy * dy;

//        int outer2 = outer_radius * outer_radius;
//        int inner2 = inner_radius * inner_radius;

//        if(distance2 <= outer2 && distance2 >= inner2) {

//            float angle = atan2f((float)-dy, (float)dx);

//            if(angle < 0) {
//                angle += 2.0f * 3.1415926f;
//            }

//            float t = angle / (2.0f * 3.1415926f);

//            int r;
//            int g;
//            int b = 0;

//            /* 红 → 橙 */

//            if(t < 0.3333f) {

//                float k = t / 0.3333f;

//                r = 255;
//                g = 80 + (int)(175.0f * k);
//            }

//            /* 橙 → 黄 */

//            else if(t < 0.6666f) {

//                float k = (t - 0.3333f) / 0.3333f;

//                r = 255 - (int)(180.0f * k);
//                g = 255;
//            }

//            /* 黄 → 绿 */

//            else {

//                float k = (t - 0.6666f) / 0.3334f;

//                r = (int)(75.0f * (1.0f - k));
//                g = 255;
//            }

//            lv_color_t color = lv_color_make(r, g, b);

//            lv_canvas_set_px(battery_ring, x, y, color, LV_OPA_COVER);
//        }
//    }
//}

/* =========================
 * 电量百分比
 * ========================= */

lv_obj_t *battery_label = lv_label_create(charging_status);

lv_label_set_text(battery_label, "75%");

lv_obj_set_style_text_color(battery_label, lv_color_hex(0xFFFFFF), 0);
lv_obj_set_style_text_font(battery_label, &lv_font_montserrat_24, 0);
lv_obj_center(battery_label);

/* =========================
 * 电池状态
 * ========================= */

lv_obj_t *battery_status_label = lv_label_create(charging_status);

lv_label_set_text(battery_status_label, "BATTERY");

lv_obj_set_style_text_color(battery_status_label, lv_color_hex(0x8A9BA8), 0);
lv_obj_set_style_text_font(battery_status_label, &lv_font_montserrat_14, 0);
lv_obj_align(battery_status_label, LV_ALIGN_CENTER, 0, 35);

    /* =========================
     * 左右区域分隔线
     * ========================= */

    lv_obj_t *charging_line = lv_obj_create(charging_status);

    lv_obj_set_width(charging_line, 2);
    lv_obj_set_height(charging_line, LV_PCT(97));
    lv_obj_align(charging_line, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_set_style_bg_color(charging_line, lv_color_hex(0x3B82F6), 0);
    lv_obj_set_style_bg_opa(charging_line, LV_OPA_60, 0);
    lv_obj_set_style_border_width(charging_line, 0, 0);
    lv_obj_set_style_outline_width(charging_line, 0, 0);
    lv_obj_set_style_shadow_width(charging_line, 0, 0);
    lv_obj_set_style_radius(charging_line, 1, 0);

    /* =========================
     * 右侧快捷功能区
     * ========================= */

    lv_obj_t *charging_status1 = lv_obj_create(func_area);

    lv_obj_set_grid_cell(charging_status1,LV_GRID_ALIGN_STRETCH, 3, 2,LV_GRID_ALIGN_STRETCH, 0, 5);
    lv_obj_set_style_bg_color(charging_status1, lv_color_hex(0x101820), 0);
    lv_obj_set_style_border_width(charging_status1, 0, 0);
    lv_obj_set_style_outline_width(charging_status1, 0, 0);
    lv_obj_set_style_shadow_width(charging_status1, 0, 0);
    lv_obj_set_style_radius(charging_status1, 5, 0);

//充电参数展示区
lv_obj_t *list1 = lv_obj_create(charging_status1);

lv_obj_set_style_bg_color(list1, lv_color_hex(0x101820), 0);
lv_obj_set_size(list1, LV_PCT(100), LV_PCT(100));
lv_obj_set_style_border_width(list1, 0, 0);
lv_obj_set_style_pad_all(list1, 10, 0);

lv_obj_set_layout(list1, LV_LAYOUT_FLEX);
lv_obj_set_flex_flow(list1, LV_FLEX_FLOW_COLUMN);
lv_obj_set_flex_align(list1,LV_FLEX_ALIGN_START,LV_FLEX_ALIGN_START,LV_FLEX_ALIGN_START);
lv_obj_set_style_pad_row(list1, 10, 0);

lv_obj_align(list1, LV_ALIGN_LEFT_MID, 0, 0);

//标题
lv_obj_t *label1 = lv_label_create(list1);
lv_label_set_text(label1, "Charging Parameters");
lv_obj_set_style_text_color(label1, lv_color_hex(0xFFFFFF), 0);
lv_obj_set_style_text_opa(label1, LV_OPA_COVER, 0);
lv_obj_set_style_text_font(label1, &lv_font_montserrat_16, 0);

//电压
lv_obj_t *label2 = lv_label_create(list1);
lv_label_set_text(label2, "Voltage:     220 V");
lv_obj_set_style_text_color(label2, lv_color_hex(0xFFFFFF), 0);
lv_obj_set_style_text_font(label2, &lv_font_montserrat_16, 0);

//电流
lv_obj_t *label3 = lv_label_create(list1);
lv_label_set_text(label3, "Current:     10 A");
lv_obj_set_style_text_color(label3, lv_color_hex(0xFFFFFF), 0);
lv_obj_set_style_text_font(label3, &lv_font_montserrat_16, 0);

//功率
lv_obj_t *label4 = lv_label_create(list1);
lv_label_set_text(label4, "Power:        2.2 kW");
lv_obj_set_style_text_color(label4, lv_color_hex(0xFFFFFF), 0);
lv_obj_set_style_text_font(label4, &lv_font_montserrat_16, 0);

    //按键区
    lv_obj_t *user_btn = lv_obj_create(charging_page);

    lv_obj_set_width(user_btn, LV_PCT(100));
    lv_obj_set_flex_grow(user_btn, 2);
    lv_obj_set_style_bg_color(user_btn, lv_color_hex(0x101820), 0);
    lv_obj_set_style_pad_all(user_btn, 10, 0);
    lv_obj_set_style_pad_hor(user_btn, 10, 0);
    lv_obj_set_style_border_width(user_btn, 0, 0);
    lv_obj_set_style_outline_width(user_btn, 0, 0);
    lv_obj_set_style_shadow_width(user_btn, 0, 0);
    lv_obj_set_style_radius(user_btn, 0, 0);

    lv_obj_set_layout(user_btn, LV_LAYOUT_FLEX);
    lv_obj_set_flex_flow(user_btn, LV_FLEX_FLOW_ROW);

    //开始按钮
    if(!btn_start)
    {
        btn_start = lv_btn_create(user_btn);

        lv_obj_t* label = lv_label_create(btn_start);

        lv_label_set_text(label, LV_SYMBOL_PLAY" Start Charging");

        lv_obj_set_flex_grow(btn_start, 2);
        lv_obj_set_height(btn_start,LV_PCT(100));

        lv_obj_set_style_bg_color(btn_start, lv_color_hex(0x22C55E), 0);
        lv_obj_set_style_bg_opa(btn_start, LV_OPA_80, 0);
        lv_obj_set_style_radius(btn_start, 8, 0);
        lv_obj_set_style_border_width(btn_start, 0, 0);
        lv_obj_set_style_shadow_width(btn_start, 0, 0);
        lv_obj_set_style_pad_all(btn_start, 8, 0);

        lv_obj_set_style_text_font(label, &lv_font_montserrat_20, 0);
        lv_obj_center(label);

        lv_obj_add_event_cb(btn_start, start_btn_event_cb, LV_EVENT_CLICKED, label);
    }

    //停止按钮
    if(!btn_stop)
    {
        btn_stop = lv_btn_create(user_btn);

        lv_obj_set_flex_grow(btn_stop, 2);
        lv_obj_set_height(btn_stop,LV_PCT(100));

        lv_obj_set_style_bg_color(btn_stop, lv_color_hex(0x475569), 0);
        lv_obj_set_style_bg_opa(btn_stop, LV_OPA_80, 0);
        lv_obj_set_style_radius(btn_stop, 8, 0);
        lv_obj_set_style_border_width(btn_stop, 0, 0);
        lv_obj_set_style_shadow_width(btn_stop, 0, 0);
        lv_obj_set_style_pad_all(btn_stop, 8, 0);

        lv_obj_t *stop_label = lv_label_create(btn_stop);
        lv_label_set_text(stop_label, LV_SYMBOL_STOP" Stop Charging");
        lv_obj_set_style_text_font(stop_label, &lv_font_montserrat_20, 0);
        lv_obj_center(stop_label);

        lv_obj_add_event_cb(btn_stop, stop_btn_event_cb, LV_EVENT_LONG_PRESSED, NULL);
    }

    //充电设置按钮
    lv_obj_t *btn2 = lv_btn_create(user_btn);

    lv_obj_set_flex_grow(btn2, 2);
    lv_obj_set_height(btn2,LV_PCT(100));
    lv_obj_set_style_bg_color(btn2, lv_color_hex(0x475569), 0);
    lv_obj_set_style_bg_opa(btn2, LV_OPA_80, 0);
    lv_obj_set_style_radius(btn2, 8, 0);
    lv_obj_set_style_border_width(btn2, 0, 0);
    lv_obj_set_style_shadow_width(btn2, 0, 0);
    lv_obj_set_style_pad_all(btn2, 8, 0);

    //恢复上一次状态
    if(charging_state)
    {
        lv_obj_t *label = lv_obj_get_child(btn_start, 0);

        lv_label_set_text(label, LV_SYMBOL_CHARGE" Charging...");
        lv_obj_set_style_bg_color(btn_start, lv_color_hex(0x3B82F6), 0);
        lv_obj_set_style_bg_opa(btn_start, LV_OPA_40, 0);
        lv_obj_set_style_text_opa(label, LV_OPA_40, 0);
        lv_obj_set_clickable(btn_start, false);
        lv_obj_set_style_bg_color(btn_stop, lv_color_hex(0xEF4444), 0);
        lv_obj_set_style_bg_color(led, lv_color_hex(0x00FF00), 0);
    }
}
